<?php
define("INC_PATH", dirname(__FILE__));
define("PROJECT_PATH", dirname(INC_PATH));
define("SHARED_PATH", INC_PATH . '/shared');
define("DB_PATH", INC_PATH . '/db');
define("PUBLIC_PATH", PROJECT_PATH . '/public');