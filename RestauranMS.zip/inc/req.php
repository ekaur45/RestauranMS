<?php
require_once "initialize.php";
echo "Required";

echo SHARED_PATH;