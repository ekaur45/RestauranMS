/// <reference path="jquery.min.js" />
/// <reference path="bootstrap.min.js" />


// ready function 
$(function() { 
    
})
function showAddOutgoingModal(){
    $("#addOutgoingModal").modal("show");
}
function showAddIncomingModal(){
    $("#addIncomingModal").modal("show");
}
